// netlify/functions/ai-voice.js
exports.handler = async () => {
  return {
    statusCode: 200,
    body: "OK"
  };
};
